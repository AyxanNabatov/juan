﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Juan.Models
{
    public class ProductSize : BaseEntity
    {
        public string Size { get; set; }
    }
}
