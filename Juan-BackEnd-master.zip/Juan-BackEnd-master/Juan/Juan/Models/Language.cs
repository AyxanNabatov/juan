﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Juan.Models
{
    public class Language : BaseEntity
    {
        public string Lang { get; set; }
        public string Flag { get; set; }
    }
}
