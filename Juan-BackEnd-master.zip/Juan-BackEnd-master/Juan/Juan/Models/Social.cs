﻿
namespace Juan.Models
{
    public class Social : BaseEntity
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}
